package edu.berkeley.cs186.database.categories;

public interface Proj2Tests extends ProjTests  { /* category marker */ }