package edu.berkeley.cs186.database.categories;

public interface PublicTests { /* category marker */ }
